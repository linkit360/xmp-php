<?php
namespace Aws\Exception;

class UnresolvedEndpointException extends \RuntimeException {}
