Change Log: `yii2-widget-rangeinput`
====================================

## Version 1.0.1

**Date:** 22-Nov-2015

- Update HTML5 input initialization

## Version 1.0.0

**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)