Change Log: `yii2-dialog`
===================================

## Version 1.0.1

**Date:** 13-Sep-2016

- (enh #3): Add Chinese Translations.
- Add github contribution and issue/PR logging templates.
- (enh #4,#5): Add Ukranian Translations.
- (enh #6): Add Polish Translations.
- (enh #7): Update Polish Translations.
- (enh #9): Allow configuration of krajee dialog JS registration position.
- Enhance PHP Documentation for all classes and methods in the extension.
- Initialize all common language i18n message files.

## Version 1.0.0

**Date:** 22-Feb-2016

- Initial release
- (enh #1): Add Dutch translations
