//webpack test
import "./css/inputmask.css";
import im from "./index";

//just for testing
window.Inputmask = im;


