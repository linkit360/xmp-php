<html>
<body>
<form action="/form/empty" method="POST">
    <input type="text" name="text" value="val">
</form>


<input type="text" name="empty_input" value="" id="empty_input" />
<textarea name="empty_textarea" id="empty_textarea" cols="30" rows="10"></textarea>

</body>
</html>