<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>

<h1>Iframe test</h1>

<iframe name="content" src="info" />

</body>
</html>