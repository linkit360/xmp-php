<?php
namespace Codeception\Exception;

class Incomplete extends \PHPUnit_Framework_IncompleteTestError
{

}
