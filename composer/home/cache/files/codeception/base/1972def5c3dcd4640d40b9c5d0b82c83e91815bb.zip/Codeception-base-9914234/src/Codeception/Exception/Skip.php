<?php
namespace Codeception\Exception;

class Skip extends \PHPUnit_Framework_SkippedTestError
{

}
